<footer class="main-footer">
&copy; {{ Carbon\Carbon::now()->format('Y') }}
                <a href="https://emicontech.com/" target="_blank">
                    Emicon Technology
                </a> 
                All rights reserved.
</footer>